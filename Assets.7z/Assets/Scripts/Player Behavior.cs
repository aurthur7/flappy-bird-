using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerBehavior : MonoBehaviour
{
    public Transform player;
    public Rigidbody2D Rigidbody;
    public float flyspeed = 5f;
    public Logicmanager Logicmanager;
    public bool birdisalive = true;
    // Start is called before the first frame update
  
    void Start()
    {
        player = GetComponent<Transform>();
        Rigidbody =GetComponent<Rigidbody2D>();
        Logicmanager = GameObject.FindGameObjectWithTag("logic").GetComponent<Logicmanager>();
       
    }

    // Update is called once per frame
    void Update()
    {
        float screenbottom = Camera.main.ViewportToWorldPoint(new Vector3(0, 0, 0)).y;
        if (Input.GetKeyDown(KeyCode.Space) && birdisalive)
        {
            Rigidbody.velocity = Vector2.up *flyspeed;
        }

        if (transform.position.y < screenbottom)
        {
            Logicmanager.gameOver();
            birdisalive=false;
        }
    }
    private void OnCollisionEnter2D(Collision2D collision)
    {
        Logicmanager.gameOver();
        birdisalive = false;
    }
}
