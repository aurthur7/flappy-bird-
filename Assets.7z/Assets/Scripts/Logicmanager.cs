using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Logicmanager : MonoBehaviour
{
    public int playscore = 0;
    public Text scoretext;
    public GameObject gameoverscreen;
    [ContextMenu("increase score")]
    public void scoreadd()
    {
        playscore += 1;
        scoretext.text = playscore.ToString();
       
    }
    public void RestartGame()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
    public void gameOver()
    {
        gameoverscreen.SetActive(true);
    }
    // Start is called before the first frame update
    void Start()
    {
       
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
