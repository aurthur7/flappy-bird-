using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour
{
    public GameObject pipe;
    public float spawnRate = 1.5f;
    private float time = 0f;
    public float heightoffset = 1.5f;
    
    // Start is called before the first frame update
    void Start()
    {
        instantiate();
    }

    // Update is called once per frame
    void Update()
    {
        if (time < spawnRate)
        {
            time += Time.deltaTime;
        }
        else
        {
            instantiate();
            time = 0f;
        }
        
        
    }
     void instantiate()
     {
        float lowestheight= transform.position.y - heightoffset;
        float highestheight= transform.position.y + heightoffset;
        Instantiate(pipe,new Vector3(transform.position.x,Random.Range(lowestheight,highestheight),0), transform.rotation);
    }
}
